This directory contains JLine native libraries extracted from JLine JAR.

You can add your own build for platforms not natively supported by JLine.
See here [1] on how to compile for your platform and here [2] how libraries
follow JLine's directory and filename conventions.

[1] https://github.com/jline/jline3/tree/master/native
[2] https://github.com/jline/jline3/blob/master/native/src/main/java/org/jline/nativ/OSInfo.java
